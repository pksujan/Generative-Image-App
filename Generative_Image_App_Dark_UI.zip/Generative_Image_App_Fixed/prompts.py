DEFAULT_NEGATIVE = ("low quality, blurry, pixelated, distorted, deformed, bad anatomy, "
                    "extra fingers, extra limbs, text, watermark, logo")
STYLE_PRESETS = {
    "None": "",
    "Photorealistic": "photorealistic, detailed textures, natural lighting",
    "Cinematic": "cinematic composition, dramatic lighting, atmospheric film still",
    "Digital art": "digital art, polished details, rich colors, professional illustration",
    "Watercolor": "watercolor painting, soft brush strokes, paper texture, delicate colors",
    "Anime": "anime illustration, clean line art, expressive details, vibrant colors",
    "Oil painting": "oil painting, visible brush strokes, textured canvas, classical art",
    "3D render": "high-quality 3D render, detailed materials, studio lighting",
}
def refine_prompt(prompt: str, style: str = "None") -> str:
    prompt = prompt.strip()
    style_text = STYLE_PRESETS.get(style, "")
    return f"{prompt}, {style_text}" if style_text else prompt
