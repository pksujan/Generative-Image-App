# Generative Image App using Stable Diffusion

Streamlit app for text-to-image, image-to-image, style presets, downloads, session history, and saved image metadata.

## Requirements
- Windows 10/11
- Python 3.10 or 3.11 recommended
- Internet connection and several GB of free disk space for model weights
- NVIDIA GPU recommended; CPU mode works but is slow

## Windows setup
Open Command Prompt in the folder containing `app.py` and `requirements.txt`, then run:

```bat
py -m venv venv
venv\Scripts\activate
python -m pip install --upgrade pip
python -m pip install torch torchvision
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

Open the local URL printed by Streamlit, usually http://localhost:8501.

## Fix missing diffusion_pytorch_model.safetensors
1. Stop Streamlit with Ctrl+C.
2. In File Explorer, open `%USERPROFILE%\.cache\huggingface\hub`.
3. Rename the folder starting with `models--stable-diffusion-v1-5--stable-diffusion-v1-5` by adding `-old` to the end. Do not delete the whole Hugging Face cache.
4. Run the app again. The model loader retries a fresh safetensors download and then tries `.bin` weights if needed.

If it still fails, check internet, disk space, model ID/access permissions, and the full error message. First model download may take several minutes.

For low-memory computers, use 384x384, 10 inference steps, and one image per run.


## Fix for `IndexError: index 21 is out of bounds`

This version creates a fresh scheduler for each image-generation request. This avoids stale scheduler step-index state across repeated generations. Replace the previous project folder with this version, then restart Streamlit.


## Frontend design
This version includes a modern dark UI with blue/purple accents, a redesigned sidebar, prompt cards, image transformation, and a session gallery. The generation backend is unchanged.
