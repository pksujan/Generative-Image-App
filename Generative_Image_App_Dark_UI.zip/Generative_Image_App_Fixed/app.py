import io
import streamlit as st
from PIL import Image
from generator import DEFAULT_MODEL, SCHEDULERS, GenParams, SDGenerator, save_image
from prompts import DEFAULT_NEGATIVE, STYLE_PRESETS, refine_prompt

st.set_page_config(page_title="DreamForge AI Studio", page_icon="🎨", layout="wide", initial_sidebar_state="expanded")

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Space+Grotesk:wght@500;600;700&display=swap');
:root { color-scheme: dark; }
.stApp { background: radial-gradient(ellipse at 15% 0%, rgba(71, 45, 145, .22), transparent 34%), #0b0d14; color: #eef0ff; font-family: 'DM Sans', sans-serif; }
[data-testid="stHeader"] { background: rgba(11,13,20,.75); }
[data-testid="stSidebar"] { background: linear-gradient(180deg, #111421 0%, #0d101a 100%); border-right: 1px solid rgba(148,163,255,.13); }
[data-testid="stSidebar"] > div:first-child { padding-top: 1.2rem; }
h1, h2, h3 { font-family: 'Space Grotesk', sans-serif !important; letter-spacing: -.035em; }
h1 { font-size: clamp(2rem, 4vw, 3.1rem) !important; }
.block-container { padding-top: 2rem; padding-bottom: 3rem; max-width: 1440px; }
.eyebrow { color: #a99bff; text-transform: uppercase; font-size: .76rem; font-weight: 700; letter-spacing: .16em; margin-bottom: .5rem; }
.hero { padding: 1.7rem 1.9rem; border: 1px solid rgba(155,140,255,.22); border-radius: 24px; background: linear-gradient(115deg, rgba(91,65,190,.20), rgba(25,31,52,.72) 55%, rgba(16,20,34,.85)); box-shadow: 0 20px 70px rgba(0,0,0,.18); margin-bottom: 1.4rem; }
.hero p { color: #aeb5ce; font-size: 1rem; margin-bottom: .2rem; }
.pill-row { display: flex; flex-wrap: wrap; gap: .5rem; margin-top: 1.1rem; }
.pill { border: 1px solid rgba(166,155,255,.25); color: #d8d3ff; background: rgba(129,105,255,.10); border-radius: 999px; padding: .36rem .7rem; font-size: .78rem; }
[data-testid="stTabs"] [role="tablist"] { gap: .5rem; border-bottom: 1px solid rgba(148,163,255,.15); }
[data-testid="stTabs"] button[role="tab"] { background: #121624; border: 1px solid rgba(148,163,255,.13); border-radius: 12px 12px 0 0; padding: .7rem 1rem; color: #aeb5ce; }
[data-testid="stTabs"] button[aria-selected="true"] { color: #fff; background: linear-gradient(135deg, rgba(113,86,255,.25), rgba(45,71,145,.22)); border-color: rgba(153,137,255,.45); }
[data-testid="stTextArea"] textarea, [data-testid="stTextInput"] input, [data-testid="stNumberInput"] input { background: #101421 !important; color: #f3f4ff !important; border: 1px solid #2b3046 !important; border-radius: 12px !important; }
[data-baseweb="select"] > div { background: #101421; border-color: #2b3046; border-radius: 10px; }
[data-testid="stSlider"] [data-baseweb="slider"] { padding-top: .35rem; }
.stButton > button, .stDownloadButton > button { border-radius: 12px; border: 1px solid rgba(160,147,255,.32); font-weight: 700; min-height: 2.8rem; transition: all .18s ease; }
.stButton > button[kind="primary"] { background: linear-gradient(100deg, #7257ff, #4b7bff); color: white; border: 0; box-shadow: 0 8px 26px rgba(90,87,255,.22); }
.stButton > button:hover, .stDownloadButton > button:hover { border-color: #9d91ff; transform: translateY(-1px); }
[data-testid="stImage"] img { border-radius: 16px; border: 1px solid rgba(166,155,255,.18); }
[data-testid="stVerticalBlockBorderWrapper"] { background: rgba(18,22,36,.6); border-color: rgba(148,163,255,.13) !important; border-radius: 18px; }
hr { border-color: rgba(148,163,255,.14); }
small, .stCaption { color: #8f98b6 !important; }
footer { visibility: hidden; }
</style>
""", unsafe_allow_html=True)

@st.cache_resource(show_spinner=False)
def load_generator(model_id: str):
    return SDGenerator(model_id)

def png_bytes(image: Image.Image) -> bytes:
    buffer = io.BytesIO()
    image.save(buffer, format="PNG")
    return buffer.getvalue()

if "history" not in st.session_state:
    st.session_state.history = []

with st.sidebar:
    st.markdown("<div class='eyebrow'>DreamForge</div><h2 style='margin-top:0'>Studio settings</h2><p style='color:#8f98b6;font-size:.9rem'>Fine-tune your image generation.</p>", unsafe_allow_html=True)
    st.divider()
    model_id = st.text_input("Hugging Face model ID", DEFAULT_MODEL, help="The model is downloaded the first time it is used.")
    scheduler = st.selectbox("Sampler", list(SCHEDULERS.keys()))
    steps = st.slider("Inference steps", 10, 50, 20, help="Fewer steps are faster for testing.")
    guidance = st.slider("Guidance scale", 1.0, 15.0, 7.5, 0.5)
    c1, c2 = st.columns(2)
    width = c1.selectbox("Width", [384, 448, 512, 576, 640, 704, 768], index=2)
    height = c2.selectbox("Height", [384, 448, 512, 576, 640, 704, 768], index=2)
    seed = st.number_input("Seed (-1 = random)", min_value=-1, max_value=2147483647, value=-1, step=1)
    num_images = st.slider("Images per run", 1, 4, 1)
    autosave = st.checkbox("Save images to outputs folder", value=True)
    st.divider()
    st.caption("Tip: Start with 384 × 384, 10 steps and one image for faster testing.")

st.markdown("""
<div class="hero">
  <div class="eyebrow">AI-powered creative workspace</div>
  <h1 style="margin:0 0 .55rem 0">Imagine it. <span style="color:#a99bff">Generate it.</span></h1>
  <p>Turn your ideas into images with Stable Diffusion. Write a prompt, choose a style, and create something original.</p>
  <div class="pill-row"><span class="pill">✦ Text to image</span><span class="pill">◈ Image transformation</span><span class="pill">▧ Session gallery</span></div>
</div>
""", unsafe_allow_html=True)

tab_text, tab_image, tab_history = st.tabs(["✦  Create image", "◈  Transform image", "▧  Gallery & history"])

def generate(mode, prompt, style, negative, init_image=None, strength=0.65):
    if not prompt.strip():
        st.warning("Please enter a prompt.")
        return
    params = GenParams(prompt=refine_prompt(prompt, style), negative_prompt=negative,
        steps=int(steps), guidance_scale=float(guidance), width=int(width), height=int(height),
        seed=int(seed), num_images=int(num_images), strength=float(strength))
    progress = st.progress(0, text="Preparing model...")
    try:
        with st.spinner("Generating image(s). The first run may download and load the model, so it can take several minutes."):
            generator = load_generator(model_id.strip() or DEFAULT_MODEL)
            generator.set_scheduler(scheduler)
            def update(fraction):
                progress.progress(max(0, min(100, int(fraction * 100))), text=f"Creating your image… {int(fraction * 100)}%")
            results = generator.text_to_image(params, update) if mode == "text" else generator.image_to_image(init_image, params, update)
    except Exception as exc:
        progress.empty()
        st.error(f"Image generation failed: {exc}")
        st.info("Try 384 × 384, one image, and 10 steps. Check your internet connection and available disk space. See README.md for model-cache repair instructions.")
        return
    progress.empty()
    if not results:
        st.warning("No images were returned.")
        return
    st.markdown("### Your creation")
    columns = st.columns(len(results))
    for col, result in zip(columns, results):
        with col:
            if result.get("flagged"):
                st.warning("The model safety checker flagged this image.")
            st.image(result["image"], caption=f"Seed: {result['seed']}", use_container_width=True)
            st.download_button("⬇ Download PNG", png_bytes(result["image"]),
                file_name=f"stable_diffusion_seed_{result['seed']}.png", mime="image/png",
                key=f"download_{mode}_{result['seed']}_{len(st.session_state.history)}")
        if autosave:
            try:
                result["saved_path"] = str(save_image(result["image"], result["meta"]))
            except OSError as exc:
                st.warning(f"Image generated but could not be saved: {exc}")
        st.session_state.history.insert(0, result)

with tab_text:
    st.markdown("### Create from a text prompt")
    st.caption("Describe the subject, environment, lighting, mood, and art style for the best results.")
    with st.container(border=True):
        prompt = st.text_area("Your prompt", "a lighthouse on a cliff at sunset, dramatic clouds, cinematic lighting", height=120, key="prompt_text")
        a, b = st.columns([1, 1])
        with a:
            style = st.selectbox("Visual style", list(STYLE_PRESETS.keys()), key="style_text")
        with b:
            negative = st.text_input("Avoid in the image (negative prompt)", DEFAULT_NEGATIVE, key="negative_text")
        generate_clicked = st.button("✦  Generate image", type="primary", key="generate_text_action", use_container_width=True)
    if generate_clicked:
        generate("text", prompt, style, negative)

with tab_image:
    st.markdown("### Transform an existing image")
    st.caption("Upload an image and describe how Stable Diffusion should change it.")
    uploaded = st.file_uploader("Choose a starting image", type=["png", "jpg", "jpeg", "webp"])
    prompt2 = st.text_area("Transformation prompt", "turn this into a watercolor painting", height=100)
    a, b = st.columns(2)
    with a:
        style2 = st.selectbox("Visual style", list(STYLE_PRESETS.keys()), key="style_image")
    with b:
        negative2 = st.text_input("Avoid in the image", DEFAULT_NEGATIVE, key="negative_image")
    strength = st.slider("Transformation strength", 0.1, 1.0, 0.65, 0.05, help="Higher values change the original image more strongly.")
    input_image = None
    if uploaded is not None:
        try:
            input_image = Image.open(uploaded).convert("RGB")
            st.image(input_image, caption="Starting image", width=320)
        except Exception:
            st.error("The uploaded file could not be read as an image.")
    if st.button("◈  Transform image", type="primary", key="generate_image", use_container_width=True):
        if input_image is None:
            st.warning("Upload a valid image first.")
        else:
            generate("image", prompt2, style2, negative2, input_image, strength)

with tab_history:
    st.markdown("### Your recent creations")
    if not st.session_state.history:
        st.info("Your generated images will appear here during this session.")
    else:
        if st.button("Clear gallery", key="clear_history"):
            st.session_state.history = []
            st.rerun()
        columns = st.columns(4)
        for index, result in enumerate(st.session_state.history):
            with columns[index % 4]:
                st.image(result["image"], caption=f"Seed: {result['seed']}", use_container_width=True)
                with st.expander("Generation details"):
                    st.json(result.get("meta", {}))
                st.download_button("⬇ Download", png_bytes(result["image"]),
                    file_name=f"history_seed_{result['seed']}.png", mime="image/png",
                    key=f"history_{index}_{result['seed']}")

st.markdown("<div style='text-align:center;color:#69728f;font-size:.8rem;padding-top:2rem'>DreamForge AI Studio · Powered by Stable Diffusion</div>", unsafe_allow_html=True)
