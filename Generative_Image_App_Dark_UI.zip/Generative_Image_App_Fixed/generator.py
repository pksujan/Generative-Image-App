import json
import random
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from typing import Optional
import torch
from PIL import Image
from diffusers import (DDIMScheduler, DPMSolverMultistepScheduler, EulerDiscreteScheduler,
                       PNDMScheduler, StableDiffusionImg2ImgPipeline, StableDiffusionPipeline)

DEFAULT_MODEL = "stable-diffusion-v1-5/stable-diffusion-v1-5"
SCHEDULERS = {"DPM++ 2M": DPMSolverMultistepScheduler, "Euler": EulerDiscreteScheduler,
              "DDIM": DDIMScheduler, "PNDM": PNDMScheduler}

@dataclass
class GenParams:
    prompt: str
    negative_prompt: str = ""
    steps: int = 20
    guidance_scale: float = 7.5
    width: int = 512
    height: int = 512
    seed: int = -1
    num_images: int = 1
    strength: float = 0.65

class SDGenerator:
    def __init__(self, model_id: str):
        self.model_id = model_id.strip() or DEFAULT_MODEL
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self.dtype = torch.float16 if self.device == "cuda" else torch.float32
        self.pipe = self._load_pipeline(StableDiffusionPipeline)
        self.img2img_pipe = None
        self.scheduler_name = "DPM++ 2M"
        self.set_scheduler(self.scheduler_name)
        if self.device == "cuda":
            try: self.pipe.enable_attention_slicing()
            except Exception: pass

    def _load_pipeline(self, pipeline_class):
        # First try cached/downloaded safetensors; if cache is incomplete, retry a fresh download.
        try:
            return pipeline_class.from_pretrained(self.model_id, torch_dtype=self.dtype, use_safetensors=True).to(self.device)
        except (OSError, ValueError) as first_error:
            try:
                return pipeline_class.from_pretrained(self.model_id, torch_dtype=self.dtype,
                    use_safetensors=True, force_download=True).to(self.device)
            except (OSError, ValueError) as second_error:
                # Some repositories provide .bin weights instead of safetensors.
                try:
                    return pipeline_class.from_pretrained(self.model_id, torch_dtype=self.dtype,
                        use_safetensors=False, force_download=True).to(self.device)
                except Exception as third_error:
                    raise RuntimeError(
                        "Stable Diffusion model could not be loaded. Check the model ID/access, internet, "
                        "free disk space, and Hugging Face cache. The loader tried cached safetensors, "
                        "a fresh safetensors download, and PyTorch .bin weights. "
                        f"Errors: {first_error} | {second_error} | {third_error}"
                    ) from third_error

    def set_scheduler(self, name: str):
        scheduler_class = SCHEDULERS.get(name)
        if scheduler_class is None:
            raise ValueError(f"Unknown scheduler: {name}")
        self.scheduler_name = name
        self.pipe.scheduler = scheduler_class.from_config(self.pipe.scheduler.config)
        if self.img2img_pipe is not None:
            self.img2img_pipe.scheduler = scheduler_class.from_config(self.img2img_pipe.scheduler.config)

    def _load_img2img(self):
        if self.img2img_pipe is None:
            self.img2img_pipe = self._load_pipeline(StableDiffusionImg2ImgPipeline)
            scheduler_class = SCHEDULERS[self.scheduler_name]
            self.img2img_pipe.scheduler = scheduler_class.from_config(self.img2img_pipe.scheduler.config)
            if self.device == "cuda":
                try: self.img2img_pipe.enable_attention_slicing()
                except Exception: pass
        return self.img2img_pipe

    def _generate(self, params: GenParams, init_image: Optional[Image.Image] = None, on_progress=None):
        if params.width < 256 or params.height < 256: raise ValueError("Width and height must be at least 256 pixels.")
        if params.width % 8 or params.height % 8: raise ValueError("Width and height must be divisible by 8.")
        if not 1 <= params.num_images <= 4: raise ValueError("Choose between 1 and 4 images.")
        actual_seed = int(params.seed) if params.seed >= 0 else random.randint(0, 2**31 - 1)
        torch_generator = torch.Generator(device=self.device).manual_seed(actual_seed)
        pipe = self.pipe if init_image is None else self._load_img2img()

        # A scheduler keeps internal step indices between calls. Create a fresh
        # scheduler for each generation to prevent stale-index errors.
        scheduler_class = SCHEDULERS[self.scheduler_name]
        pipe.scheduler = scheduler_class.from_config(pipe.scheduler.config)

        args = {"prompt": [params.prompt] * params.num_images,
                "negative_prompt": [params.negative_prompt] * params.num_images,
                "num_inference_steps": int(params.steps), "guidance_scale": float(params.guidance_scale),
                "generator": torch_generator}
        if init_image is None:
            args.update(width=int(params.width), height=int(params.height))
        else:
            args.update(image=init_image.convert("RGB").resize((int(params.width), int(params.height))), strength=float(params.strength))
        pipe.set_progress_bar_config(disable=True)
        def callback(pipe_obj, step_index, timestep, callback_kwargs):
            if on_progress: on_progress((step_index + 1) / max(int(params.steps), 1))
            return callback_kwargs
        try:
            result = pipe(**args, callback_on_step_end=callback)
        except TypeError:
            def old_callback(step, timestep, latents):
                if on_progress: on_progress((step + 1) / max(int(params.steps), 1))
            result = pipe(**args, callback=old_callback, callback_steps=1)
        flagged = getattr(result, "nsfw_content_detected", None) or []
        outputs = []
        for i, image in enumerate(result.images):
            image_seed = actual_seed + i
            metadata = asdict(params)
            metadata.update(model_id=self.model_id, scheduler=pipe.scheduler.__class__.__name__,
                device=self.device, seed=image_seed, mode="image-to-image" if init_image is not None else "text-to-image",
                created_at=datetime.now().isoformat(timespec="seconds"))
            outputs.append({"image": image, "seed": image_seed,
                "flagged": bool(flagged[i]) if i < len(flagged) else False, "meta": metadata})
        if on_progress: on_progress(1.0)
        return outputs

    def text_to_image(self, params: GenParams, on_progress=None):
        return self._generate(params, on_progress=on_progress)

    def image_to_image(self, image: Image.Image, params: GenParams, on_progress=None):
        if image is None: raise ValueError("Please upload a starting image.")
        return self._generate(params, init_image=image, on_progress=on_progress)

def save_image(image: Image.Image, metadata: dict, output_dir="outputs") -> Path:
    folder = Path(output_dir); folder.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    stem = f"image_seed_{metadata.get('seed', 'unknown')}_{timestamp}"
    image_path = folder / f"{stem}.png"
    image.save(image_path, format="PNG")
    (folder / f"{stem}.json").write_text(json.dumps(metadata, indent=2, ensure_ascii=False), encoding="utf-8")
    return image_path
